# 🚀 ЗАПУСК ПРИЛОЖЕНИЙ

## Быстрый старт (рекомендуется)

### Главное меню
**Файл:** `start.py`

**Запуск:**
```batch
cd knowledge_base_v2
python start.py
```

**Что делает:**
- Интерактивное меню выбора
- Удобный ввод путей к папкам
- Проверка существования папок
- Автоматическое создание папок
- Запуск всех функций из одного места

**Меню:**
```
1. 🔍 OCR Распознавание PDF
2. 📊 Агрегация данных в JSON
3. 🧮 Калькулятор (CLI)
4. 🌐 Калькулятор (Web)
5. ⚙️  Проверка OCR компонентов
6. ❌ Выход
```

## Файлы для запуска

### 1. OCR Распознавание
**Файл:** `run_ocr.py`

**Запуск:**
```batch
cd knowledge_base_v2
python run_ocr.py
```

**Что делает:**
- Интерактивный ввод пути к папке с PDF
- Показывает примеры путей
- Проверяет существование папки
- Показывает список найденных PDF
- Запрашивает подтверждение
- Распознает текст из всех PDF
- Сохраняет результаты в папку `ocr_results/`

**Примеры:**
```batch
# Интерактивный режим (запросит путь)
python run_ocr.py

# Указать путь напрямую
python run_ocr.py C:/Users/New/Desktop/пдф

# Распознать один файл
python run_ocr.py --file document.pdf
```

**Требования:**
- Установленный Tesseract-OCR с русским языком
- Установленный Poppler

### 2. Агрегация данных
**Файл:** `aggregate_json.py`

**Запуск:**
```batch
cd knowledge_base_v2
python aggregate_json.py
```

**Что делает:**
- Интерактивный ввод пути к папке с PDF (опционально)
- Предлагает включить PDF в агрегацию
- Проверяет наличие OCR
- Собирает все данные в один JSON файл
- Загружает формулы, практики, значения чисел
- Загружает полный текст из SQLite базы
- Создает файл `data/complete_knowledge_base.json`

**Примеры:**
```batch
# Интерактивный режим (спросит про PDF)
python aggregate_json.py

# Указать путь сразу
python aggregate_json.py C:/Users/New/Desktop/пдф
```

**Результат:**
- Файл `data/complete_knowledge_base.json` (~1-100 MB)
- Содержит все данные в одном месте

### 3. Пользовательское приложение (CLI)
**Файл:** `calculator_app.py`

**Запуск:**
```batch
cd knowledge_base_v2
python calculator_app.py
```

**Что делает:**
- Интерактивное меню
- Расчет по дате рождения
- Расчет по ФИО
- Просмотр практик
- Значения чисел

**Меню:**
```
1. Полный расчет по дате рождения
2. Расчет по ФИО
3. Просмотр практик
4. Значения чисел
5. Выход
```

### 4. Пользовательское приложение (Web)
**Файл:** `app/index.html`

**Запуск:**
```batch
# Просто открыть файл
start knowledge_base_v2/app/index.html

# Или через сервер
cd knowledge_base_v2/app
python -m http.server 8000
# Открыть http://localhost:8000
```

**Что делает:**
- Веб-интерфейс калькулятора
- Красивый дизайн
- Расчет всех чисел
- Визуализация чакр

### 5. Проверка OCR
**Файл:** `check_ocr.py`

**Запуск:**
```batch
cd knowledge_base_v2
python check_ocr.py
```

**Что делает:**
- Проверяет установлен ли Tesseract
- Проверяет установлен ли Poppler
- Проверяет доступность русского языка
- Показывает инструкции если что-то не установлено

## Быстрый старт

### 🌟 Рекомендуемый способ (главное меню):
```batch
cd knowledge_base_v2
python start.py
```

### Для пользователя (только калькулятор):
```batch
cd knowledge_base_v2
python calculator_app.py
```

### Для распознавания PDF (с интерактивным вводом):
```batch
cd knowledge_base_v2
python run_ocr.py
# Или сразу с путем:
python run_ocr.py C:/Users/New/Desktop/пдф
```

### Для создания полной базы (с интерактивным вводом):
```batch
cd knowledge_base_v2
python aggregate_json.py
# Или сразу с путем:
python aggregate_json.py C:/Users/New/Desktop/пдф
```

### Для веб-приложения:
```batch
start knowledge_base_v2/app/index.html
```

## Структура запускаемых файлов

```
knowledge_base_v2/
├── start.py               # 🌟 Главное меню (рекомендуется)
├── run_ocr.py             # OCR распознавание PDF
├── aggregate_json.py      # Агрегация данных в JSON
├── calculator_app.py      # CLI калькулятор
├── check_ocr.py          # Проверка OCR
├── app/
│   └── index.html        # Web калькулятор
└── data/                 # Данные
    ├── formulas.json     # Формулы
    ├── practices.json    # Практики
    └── complete_knowledge_base.json  # Полная база
```

## Какой файл когда использовать

| Задача | Файл | Команда | Интерактивный ввод |
|--------|------|---------|-------------------|
| **🌟 Всё в одном** | **start.py** | **`python start.py`** | **✅ Да** |
| Распознать PDF | run_ocr.py | `python run_ocr.py` | ✅ Да |
| Собрать все данные | aggregate_json.py | `python aggregate_json.py` | ✅ Да |
| Калькулятор (CLI) | calculator_app.py | `python calculator_app.py` | - |
| Калькулятор (Web) | app/index.html | `start app/index.html` | - |
| Проверить OCR | check_ocr.py | `python check_ocr.py` | - |

## Примеры использования

### Пример 1: Только калькулятор
```batch
cd knowledge_base_v2
python calculator_app.py
# Вводим: 15, 6, 1990
# Получаем: число рождения, путь жизни, финансовый канал, чакры
```

### Пример 2: Распознать и собрать
```batch
cd knowledge_base_v2
python run_ocr.py C:/Users/New/Desktop/пдф
python aggregate_json.py
# Получаем полную базу в JSON
```

### Пример 3: Web приложение
```batch
cd knowledge_base_v2/app
python -m http.server 8000
# Открываем браузер: http://localhost:8000
```

## Интерактивный ввод пути

### Как это работает

Скрипты `start.py`, `run_ocr.py` и `aggregate_json.py` поддерживают удобный ввод пути:

**Если путь не указан:**
```
ВЫБОР ПАПКИ С PDF ФАЙЛАМИ
============================================================

Примеры путей:
  Windows: C:/Users/Имя/Desktop/пдф
  Windows: C:/Users/Имя/Documents/PDFs
  Linux/Mac: /home/имя/documents/pdfs

Введите путь к папке с PDF [C:/Users/New/Desktop/пдф]: 
```

**Возможности:**
- ✅ Показывает примеры путей
- ✅ Поддерживает пути по умолчанию
- ✅ Проверяет существование папки
- ✅ Показывает количество PDF
- ✅ Показывает список файлов
- ✅ Запрашивает подтверждение
- ✅ Предлагает создать папку если не существует

### Форматы путей

**Windows:**
```
C:/Users/Имя/Desktop/пдф
C:\Users\Имя\Desktop\пдф
C:/Users/Имя/Documents/PDFs
```

**Linux/Mac:**
```
/home/имя/documents/pdfs
~/documents/pdfs
```

**Специальные символы:**
- `~` или `~username` - домашняя папка
- `.` - текущая папка
- `..` - родительская папка

## Зависимости

### Только калькулятор:
- Ничего не нужно устанавливать!
- Работает с JSON файлами из папки data/

### OCR распознавание:
```batch
pip install pytesseract pdf2image pillow
# + Tesseract-OCR с русским языком
# + Poppler
```

### Все остальное:
- Стандартный Python 3.8+
- Ничего дополнительного не нужно
