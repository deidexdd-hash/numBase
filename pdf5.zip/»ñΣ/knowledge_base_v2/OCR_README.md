# 📝 OCR УСТАНОВКА И ЗАПУСК

## Быстрый старт (3 шага)

### Шаг 1: Установить Tesseract-OCR

**Скачать:**
```
https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-5.3.3.20231005.exe
```

**При установке:**
1. ✅ Отметьте галочку "Russian" в списке языков
2. Запомните путь (обычно `C:\Program Files\Tesseract-OCR`)

### Шаг 2: Добавить в PATH

**Автоматически:**
```batch
setup_ocr.bat
```

**Вручную:**
1. Win + R → `sysdm.cpl` → Enter
2. Дополнительно → Переменные среды
3. Path → Изменить → Создать
4. Добавить: `C:\Program Files\Tesseract-OCR`
5. Перезапустить терминал

### Шаг 3: Установить Poppler

**Скачать:**
```
https://github.com/oschwartz10612/poppler-windows/releases/download/v24.08.0-0/Release-24.08.0-0.zip
```

**Установка:**
1. Распаковать в `C:\poppler`
2. Добавить в PATH: `C:\poppler\bin`

### Шаг 4: Установить Python библиотеки

```batch
pip install pytesseract pdf2image pillow
```

## Проверка установки

```batch
# Проверить Tesseract
tesseract --version

# Проверить Poppler
pdftoppm -v

# Проверить Python
python -c "import pytesseract; print('OK:', pytesseract.get_tesseract_version())"
python -c "import pytesseract; print('Языки:', pytesseract.get_languages())"
```

Должно показать версию и список языков включая `'rus'`

## Запуск OCR обработки

### Полная пересборка (со всеми PDF)

```batch
cd knowledge_base_v2
python processor/build_full_database.py
```

**Время:** 10-30 минут (зависит от количества сканов)

**Результат:**
- 📝 22 PDF с текстом (быстро)
- 🔍 61 PDF со сканами (OCR, долго)
- 💾 SQLite база ~50-100 MB

### Только OCR для сканов (если база уже есть)

```batch
cd knowledge_base_v2
python -c "
from processor.build_full_database import *
ocr = OCRProcessor()
if ocr.tesseract_available:
    print('OCR готов к работе')
else:
    print('Установите Tesseract')
"
```

## Пример вывода при обработке

```
================================================================================
СОЗДАНИЕ ПОЛНОТЕКСТОВОЙ БАЗЫ ДАННЫХ С OCR
================================================================================

Проверка OCR:
  ✓ Tesseract с русским языком доступен
  ✓ OCR будет выполнен для сканированных PDF

Найдено PDF файлов: 83
Примерный размер: ~210 MB

[ 1/83] 12 Ансестологических циклов.pdf...    OCR обработка (300 DPI)...12345678 ✓
[ 2/83] Алгоритм подбора схемы.pdf...         📝 4,891 символов
[ 3/83] Алгоритм_выбора_техники.pdf...        OCR обработка (300 DPI)...123 ✓
...

ИТОГИ:
  Обработано: 83
  OCR обработано: 61
  Всего символов: 2,500,000
```

## Решение проблем

### "tesseract is not installed"

**Проверить PATH:**
```batch
where tesseract
```

Должно показать путь. Если нет:
- Перезапустите терминал
- Проверьте что путь добавлен правильно

### "Failed to import Poppler"

**Windows:**
```batch
# Проверить
c:\poppler\bin\pdftoppm -v

# Если не работает - добавьте в PATH через:
setx PATH "%PATH%;C:\poppler\bin"
```

### Низкое качество OCR

**Увеличить DPI в скрипте:**
```python
# В build_full_database.py измените:
text = self.ocr.extract_with_ocr(pdf_path, dpi=400)  # Было 300
```

**Но это увеличит время обработки в 2 раза!**

### Русский язык не распознается

**Проверить:**
```batch
tesseract --list-langs
```

Должен быть в списке `rus`

**Если нет:**
1. Переустановите Tesseract
2. На этапе выбора компонентов найдите "Language data"
3. Отметьте "Russian"

## Использование после OCR

```python
from knowledge_base import HybridKnowledgeBase

kb = HybridKnowledgeBase()

# Теперь поиск работает по ВСЕМ 83 PDF!
results = kb.search_documents("финансовый канал")
print(f"Найдено: {len(results)} документов")

for doc in results:
    print(f"  📄 {doc['title']}")
    print(f"     Метод: {doc.get('extraction_method', 'unknown')}")
```

## Размеры после OCR

| Компонент | Размер |
|-----------|--------|
| JSON формулы | 41 KB |
| SQLite (22 текстовых) | 0.8 MB |
| SQLite (83 с OCR) | 50-100 MB |
| **Итого** | **50-100 MB** |

## Автоматическая установка (всё вместе)

**Сохраните как `install_all.bat`:**

```batch
@echo off
echo Installing Tesseract OCR components...

# Python библиотеки
pip install pytesseract pdf2image pillow

# Проверка
echo.
echo Checking installation...
python -c "import pytesseract; print('Tesseract:', pytesseract.get_tesseract_version())"
python -c "import pytesseract; langs = pytesseract.get_languages(); print('Russian:', 'rus' in langs)"

echo.
echo Done! Run: python processor/build_full_database.py
pause
```

**Запустите:**
```batch
install_all.bat
```

## Готово!

После установки Tesseract база будет содержать полный текст из всех 83 PDF с качественным OCR русского языка.

**Запуск:**
```batch
cd knowledge_base_v2
python processor/build_full_database.py
```

**Использование:**
```batch
python knowledge_base.py
```
