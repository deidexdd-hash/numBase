#!/usr/bin/env python3
"""
ЗАПУСКАЛКА ИНСТРУМЕНТА ОБРАБОТКИ
Объединяет все этапы подготовки данных.
"""

import subprocess
import sys
from pathlib import Path

print("=" * 70)
print("  ИНСТРУМЕНТ ПОДГОТОВКИ ДАННЫХ")
print("  Ансестология и Нумерология")
print("=" * 70)
print()

processor_dir = Path(__file__).parent

def run_script(script_name):
    """Запустить скрипт обработки"""
    script_path = processor_dir / script_name
    print(f"\n▶ Запуск: {script_name}")
    print("-" * 70)
    
    try:
        result = subprocess.run(
            [sys.executable, str(script_path)],
            cwd=processor_dir.parent,
            capture_output=False,
            text=True
        )
        return result.returncode == 0
    except Exception as e:
        print(f"Ошибка: {e}")
        return False

# Этап 1: Создание базы данных из PDF
print("ЭТАП 1: Создание структурированной базы данных")
print("=" * 70)

if run_script("create_database.py"):
    print("\n✅ База данных создана успешно!")
else:
    print("\n❌ Ошибка при создании базы данных")
    sys.exit(1)

# Этап 2: Обработка PDF (опционально, если PyPDF2 установлен)
print("\n\n" + "=" * 70)
print("ЭТАП 2: Извлечение контента из PDF (опционально)")
print("=" * 70)

print("\nПропускаем извлечение текста из PDF.")
print("База данных уже содержит все формулы и структуры.")
print("Если нужно извлечь текст из PDF для поиска, запустите:")
print("  python processor/process.py")

print("\n\n" + "=" * 70)
print("  ✅ ПОДГОТОВКА ЗАВЕРШЕНА!")
print("=" * 70)
print()
print("Созданы файлы данных:")
print("  📄 data/formulas.json - все формулы расчетов")
print("  📄 data/practices.json - практики и техники")
print("  📄 data/algorithms.json - алгоритмы и схемы")
print("  📄 data/number_meanings.json - значения чисел")
print("  📄 data/index.json - общий индекс")
print()
print("Теперь можно создавать приложение в папке app/")
print("=" * 70)
