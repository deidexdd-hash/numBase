# Архитектура Приложения Ансестологии и Нумерологии

---

## 🔍 Аудит 2026-02-19 — Итоги и статус рефакторинга

### Критические проблемы (исправляются в Phase 5)
| # | Проблема | Статус |
|---|----------|--------|
| 1 | Хардкод пути `C:/Users/New/Desktop/пдф` в config.json | ✅ Исправлено — `os.getenv("PDF_FOLDER")` |
| 2 | Два HTTP-сервера: порт 3000 (статика) + порт 8000 (API) | ✅ Исправлено — единый `main.py` FastAPI порт 8000 |
| 3 | Поиск через `LIKE` вместо SQLite FTS5 | ✅ Исправлено — FTS5 + BM25, `processor/rebuild_fts.py` |
| 4 | Дублированная папка `knowledge_base_v2/knowledge_base_v2/` | ✅ Удалено |
| 5 | Нет `requirements.txt` — зависимости не зафиксированы | ✅ Создан `requirements.txt` |
| 6 | Монолитный `app/index.html` (839 строк) | ✅ Переписан — 519 строк, тёмная тема, новый UX |
| 7 | Код написан в транслите | ✅ Новые файлы на английском/русском |

### Целевая архитектура (после Phase 5)

```
┌─────────────────────────────────────────────────────────┐
│                   ПОЛЬЗОВАТЕЛЬ                          │
└──────────────┬──────────────────────────┬───────────────┘
               │ Browser                  │ Telegram
    ┌──────────▼──────────┐    ┌──────────▼──────────────┐
    │  Web SPA            │    │  Telegram Bot            │
    │  (app/index.html)   │    │  (telegram_bot.py)       │
    └──────────┬──────────┘    └──────────┬───────────────┘
               │ HTTP/REST                │ python-telegram-bot
┌──────────────▼──────────────────────────▼───────────────┐
│   main.py — FastAPI (единый сервер, порт 8000)           │
│   GET /          → StaticFiles → app/index.html          │
│   GET /api/search    → FTS5 поиск по SQLite              │
│   GET /api/calculate → нумерологические расчёты          │
│   POST /api/ask      → RAG + OpenAI                      │
│   GET /api/history   → история расчётов                  │
└────────────────────────┬────────────────────────────────┘
                         │
          ┌──────────────┼──────────────┐
          │              │              │
 ┌────────▼───────┐ ┌────▼────────┐ ┌──▼──────────────┐
 │ knowledge_     │ │ formulas/   │ │ history.db       │
 │ base.db        │ │ practices   │ │ (user profiles + │
 │ + FTS5 index   │ │ JSON files  │ │  calculations)   │
 └────────────────┘ └─────────────┘ └──────────────────┘
          │
 ┌────────▼────────┐
 │ OpenAI API      │
 │ (RAG context)   │
 └─────────────────┘
```

### Правила именования (после рефакторинга)
- **Код Python**: переменные и функции — `snake_case` английский
- **Комментарии**: русский язык
- **HTML/JS**: английские идентификаторы, русский UI-текст
- **Конфигурация**: все пути через `.env` переменные

---


## 📊 Анализ Данных

### Типы данных:
1. **PDF (83 файла)** → OCR → TXT → SQLite/JSON
   - Теоретические материалы по ансестологии
   - Практики и техники
   - Расчёты и формулы
   - Медитации и молитвы

2. **HTML/HTM (2 файла)** → TXT → SQLite/JSON
   - Дополнительные источники
   - Google Таблицы (экспорт)

3. **JSON файлы:**
   - `complete_knowledge_base.json` - агрегированные данные (41KB)
   - `formulas.json` - 15 формул расчётов
   - `practices.json` - 8 практик
   - `number_meanings.json` - 11 значений чисел
   - `algorithms.json` - 2 алгоритма

### Структура знаний:
```
📚 Категории:
├── Нумерология (основные расчёты)
├── Ансестология (работа с родом)
├── Практики (техники проработки)
├── Финансы (родовые программы денег)
├── Отношения (типология)
├── Профессия (предназначение)
└── Здоровье (родовые амплитуды)
```

## 🏗️ Архитектура Системы

### 1. Двухуровневая архитектура

#### Уровень 1: Lightweight (JSON)
- **Размер:** ~41KB
- **Назначение:** Быстрые расчёты для калькулятора
- **Данные:** Формулы, практики, значения чисел
- **Использование:** Офлайн, мгновенный отклик

#### Уровень 2: Full-text (SQLite)
- **Размер:** ~50-100MB (с OCR)
- **Назначение:** Полнотекстовый поиск
- **Данные:** Весь текст из 83 PDF
- **Использование:** Поиск, анализ, AI-интеграция

### 2. Компоненты

```
knowledge_base_v2/
├── 📁 data/                      # Готовые данные
│   ├── complete_knowledge_base.json  # Агрегированные данные
│   ├── knowledge_base.db            # SQLite база
│   └── source/                       # Исходные JSON
│
├── 📁 processor/                 # Обработчики
│   ├── ocr_utils.py              # OCR модуль
│   ├── build_full_database.py    # Создание SQLite
│   └── create_database.py        # Создание JSON
│
├── 📁 app/                       # Приложение
│   ├── calculator/               # Калькулятор
│   ├── search/                   # Поиск
│   └── ui/                       # Интерфейс
│
└── 📁 docs/                      # Документация
```

## 🎯 Варианты Использования

### 1. CLI Калькулятор (MVP - ГОТОВО)
```bash
python calculator_cli.py
```

**Функции:**
- Путь жизни (Life Path)
- Число рождения
- Число судьбы по ФИО
- Финансовый канал
- Баланс чакр
- Поиск по базе
- 8 практик
- 15 формул

### 2. Web Калькулятор (Phase 2 - ГОТОВО)
```bash
# Открыть в браузере
open app/index.html
```

**Возможности:**
- Адаптивный дизайн (mobile-friendly)
- 9 разделов с боковым меню
- Загрузка JSON данных через fetch API
- Поиск по формулам и практикам
- Красивые карточки результатов
- Статистика базы данных

### 3. Python API
```python
from knowledge_base import HybridKnowledgeBase

kb = HybridKnowledgeBase()

# Расчёты
result = kb.calculate_life_path(15, 6, 1990)
print(f"Путь жизни: {result['value']}")  # 4
print(f"Значение: {result['meaning']['title']}")  # "Четверка - Стабильность"

# Поиск
docs = kb.search_documents("финансовый канал", limit=5)
```

### 2. Поиск по Базе Знаний
```python
# Полнотекстовый поиск
docs = kb.search("финансовый канал", limit=5)
for doc in docs:
    print(f"{doc['title']}: {doc['content'][:200]}")

# Поиск по категории
financial = kb.search_by_category("financial")
```

### 3. Практики и Рекомендации
```python
# Получить практику
practice = kb.get_practice("genogram_practice")
print(practice['steps'])

# Рекомендации на основе расчётов
recommendations = kb.get_recommendations(life_path=4)
```

### 4. AI-Интеграция
```python
# Контекст для LLM
context = kb.get_context_for_query("проблемы с деньгами")
# Отправить в OpenAI/Claude
```

## 🚀 Технологический Стек

### Backend:
- **Python 3.8+** - Основной язык
- **SQLite** - Полнотекстовый поиск
- **FastAPI** - API сервер (опционально)

### Frontend:
- **Vanilla JS** или **React/Vue**
- **Chart.js** - Визуализация
- **Marked.js** - Markdown рендеринг

### OCR:
- **Tesseract-OCR** - Распознавание текста
- **pdf2image** - Конвертация PDF
- **Poppler** - Работа с PDF

### AI (опционально):
- **OpenAI API** - GPT для анализа
- **LangChain** - RAG система
- **ChromaDB** - Векторный поиск

## 📱 Реализованные Форматы

### ✅ 1. CLI Application (MVP Complete)
**Файл:** `calculator_cli.py`
- Интерактивное меню
- 5 видов расчётов
- Поиск по базе
- Статистика
- Работа офлайн

### ✅ 2. Web Application (Phase 2 - 60%)
**Файл:** `app/index.html`
- Адаптивный дизайн
- Боковое меню навигации
- 9 разделов
- Загрузка JSON через fetch API
- Поиск по формулам и практикам
- Mobile-friendly

### 🔄 3. Telegram Bot (Phase 3 - Planned)
- Быстрые расчёты
- Поиск по команде
- Доступ с телефона

### 🔄 4. Desktop App (Phase 4 - Planned)
- Electron/Tauri обёртка
- Полный доступ к файлам
- Локальная база SQLite
- Работа офлайн

## 🔄 Прогресс Разработки

### ✅ Этап 1: MVP (ЗАВЕРШЁН - 18.02.2026)
- [x] Сбор и OCR данных (83 PDF)
- [x] Создание JSON базы (15 формул, 8 практик)
- [x] Базовый калькулятор (5 видов расчётов)
- [x] CLI интерфейс (calculator_cli.py)
- [x] SQLite база (105 документов)

**Результат:** Полнофункциональный CLI калькулятор

### ✅ Этап 2: Core (ЗАВЕРШЁН - 18.02.2026)
- [x] Web-интерфейс (app/index.html)
- [x] API сервер (api_server.py)
- [x] Полнотекстовый поиск (по 105 документам)
- [x] Система практик (8 практик)
- [x] Адаптивный дизайн (mobile-friendly)
- [x] CORS поддержка

**Результат:** Полноценное веб-приложение с API

### 🔄 Этап 3: Advanced (В ПРОЦЕССЕ)
- [ ] AI-консультант (OpenAI интеграция)
- [ ] Пользовательские профили
- [ ] История расчётов
- [ ] Telegram бот

### ⏳ Этап 4: Scale (ЗАПЛАНИРОВАНО)
- [ ] Мобильное приложение (React Native)
- [ ] Сообщество и обмен
- [ ] Платформа для практиков
- [ ] Платформа для практиков

## 📊 Структура Данных

### Formula Schema:
```json
{
  "id": "life_path",
  "name": "Путь жизни",
  "category": "numerology",
  "inputs": [{"name": "day", "type": "number"}, ...],
  "formula_code": "reduce_to_single(day + month + year)",
  "source_files": [...]
}
```

### Document Schema:
```json
{
  "id": 1,
  "filename": "document.pdf",
  "title": "Название",
  "type": "pdf",
  "content": "Полный текст...",
  "categories": ["finance", "practice"]
}
```

## 🔐 Безопасность

- Все данные локальные
- Нет передачи персональных данных
- Шифрование SQLite (опционально)
- Бэкапы автоматические

## 📝 Документация

- API Reference
- User Guide
- Developer Guide
- Architecture Decision Records

## 📁 Структура Проекта (Актуальная)

```
knowledge_base_v2/
├── 📁 data/                      # База данных
│   ├── complete_knowledge_base.json  # Агрегированные данные
│   ├── knowledge_base.db            # SQLite (107 документов)
│   ├── history.db                   # История пользователей
│   ├── formulas.json                # 15 формул
│   ├── practices.json               # 8 практик
│   ├── number_meanings.json         # 11 значений чисел
│   └── algorithms.json              # 2 алгоритма
│
├── 📁 app/                       # Web приложение ✅
│   └── index.html                   # Главная страница (Phase 2)
│
├── 📁 processor/                 # Обработчики
│   ├── ocr_utils.py                 # OCR модуль
│   ├── build_full_database.py       # Создание SQLite
│   └── create_database.py           # Создание JSON
│
├── 📁 docs/                      # Документация
│   ├── Architecture.md              # Архитектура
│   ├── DevelopmentPlan.xml          # План разработки
│   ├── README.md                    # Инструкция
│   └── *.md                         # Доп. документация
│
├── Core (5):                     # Ядро системы
│   ├── knowledge_base.py            # Основной класс ✅
│   ├── ai_consultant.py             # AI с RAG ✅
│   ├── history_manager.py           # История ✅
│   ├── api_server.py                # HTTP API ✅
│   └── telegram_bot.py              # Telegram ✅
│
├── Interfaces (3):               # Интерфейсы
│   ├── manage.py                    # Центральный управление ✅ NEW
│   ├── calculator_cli.py            # CLI калькулятор ✅
│   └── launch_web.py                # Web+API launcher ✅
│
├── Config:
│   ├── .env                         # API ключи (не в git!)
│   ├── config.json                  # Настройки приложения
│   └── start.py                     # Legacy launcher
│
└── Tools:
    ├── aggregate_json.py            # Агрегация данных
    ├── run_ocr.py                   # OCR обработка
    └── check_ocr.py                 # Проверка OCR
```

## 📊 Метрики Проекта

- **PDF обработано:** 83
- **HTML обработано:** 2
- **Всего документов:** 105
- **Объём текста:** 898,830 символов
- **Размер SQLite:** ~0.86 MB
- **Размер JSON:** 41 KB
- **Формул:** 15
- **Практик:** 8
- **Файлов кода:** 10+

## 🌐 API Endpoints

### Base URL
```
http://localhost:8000
```

### Endpoints

#### 1. Поиск по документам
```
GET /api/search?q=query&limit=10
```

**Parameters:**
- `q` - поисковый запрос (required)
- `limit` - максимум результатов (default: 10)

**Response:**
```json
{
  "query": "finansovyj kanal",
  "results": [
    {
      "id": 1,
      "filename": "document.pdf",
      "title": "Nazvanie",
      "type": "pdf",
      "categories": ["finance"],
      "snippet": "...",
      "content_length": 1234
    }
  ],
  "total": 5
}
```

#### 2. Получить документ
```
GET /api/documents?id=1
```

#### 3. Статистика
```
GET /api/stats
```

**Response:**
```json
{
  "documents": 105,
  "total_chars": 898830,
  "size_mb": 0.86
}
```

#### 4. Категории
```
GET /api/categories
```

## 🎛️ Централизованное Управление (manage.py) - NEW!

### Архитектура управления:
```
┌─────────────────────────────────────────┐
│           manage.py                     │
│  (Centralized Project Manager)          │
└─────────────────┬───────────────────────┘
                  │
    ┌─────────────┼─────────────┐
    │             │             │
    ▼             ▼             ▼
┌───────┐    ┌───────┐    ┌──────────┐
│Setup  │    │Diag   │    │Launch    │
│.env   │    │Check  │    │Components│
│config │    │Test   │    │          │
└───────┘    └───────┘    └────┬─────┘
                               │
          ┌────────────────────┼────────────────────┐
          │                    │                    │
          ▼                    ▼                    ▼
   ┌─────────────┐      ┌──────────┐       ┌──────────────┐
   │  calculator │      │  launch  │       │  telegram    │
   │     _cli.py │      │  _web.py │       │   _bot.py    │
   └─────────────┘      └──────────┘       └──────────────┘
```

### Возможности manage.py:

1. **Настройка окружения**
   - Создание `.env` файла
   - Установка API ключей
   - Конфигурация путей

2. **Диагностика системы**
   - Проверка структуры проекта
   - Проверка зависимостей
   - Тестирование модулей
   - Проверка согласованности данных

3. **Запуск компонентов**
   - CLI калькулятор
   - Web + API
   - Telegram бот

### Использование:

```bash
python manage.py

# Меню:
# 1. Настройка окружения (.env, config)
# 2. Диагностика системы
# 3. CLI Калькулятор
# 4. Web + API (localhost:3000)
# 5. Telegram Bot
# 6. Информация о проекте
# 7. Выход
```

### Конфигурация (config.json):

```json
{
  "version": "2.1",
  "data_sources": {
    "pdf_folder": "C:/Users/New/Desktop/пдф",
    "auto_load_html": true
  },
  "features": {
    "ai_enabled": true,
    "telegram_enabled": true,
    "web_enabled": true,
    "cli_enabled": true
  },
  "api": {
    "host": "localhost",
    "port": 8000,
    "web_port": 3000
  }
}
```

## 🔄 Поток Данных Между Модулями

### Схема взаимодействия:
```
Пользователь
    │
    ├──► CLI (calculator_cli.py) ◄──────┐
    │         │                          │
    ├──► Web (app/index.html) ◄─────────┤
    │         │                          │
    └──► Telegram (telegram_bot.py) ◄───┤
              │                          │
              ▼                          │
    ┌──────────────────────┐            │
    │   KnowledgeBase      │            │
    │   (knowledge_base.py)│            │
    └──────────┬───────────┘            │
               │                        │
      ┌────────┴────────┐               │
      │                 │               │
      ▼                 ▼               │
┌──────────┐    ┌──────────┐          │
│   JSON   │    │  SQLite  │          │
│  (data/) │    │  (data/) │          │
└──────────┘    └────┬─────┘          │
                     │                │
                     ▼                │
          ┌─────────────────┐         │
          │  AI Consultant  │◄────────┘
          │(ai_consultant.py)
          └────────┬────────┘
                   │
                   ▼
          ┌─────────────────┐
          │  OpenAI API     │
          └─────────────────┘
```

### Потоки данных:

1. **Чтение данных:**
   - `knowledge_base.py` → читает JSON и SQLite
   - `ai_consultant.py` → ищет в SQLite
   - `history_manager.py` → пишет/читает history.db

2. **Запись данных:**
   - `aggregate_json.py` → создаёт JSON из PDF/HTML
   - `build_full_database.py` → создаёт SQLite
   - `history_manager.py` → сохраняет историю

3. **Интеграция:**
   - Все модули используют `knowledge_base.py` как основу
   - `ai_consultant` использует данные для контекста
   - `telegram_bot` использует всё для ответов

## 🚀 Запуск Компонентов

### Рекомендуемый способ (manage.py):
```bash
python manage.py
# Выберите нужный пункт меню
```

### Альтернативные способы:

**API сервер**
# Server started at http://localhost:8000
```

### 2. Открыть Web приложение
```bash
# Вариант 1: Прямо открыть файл
open app/index.html

# Вариант 2: Через Python HTTP сервер
cd app && python -m http.server 3000
# Открыть http://localhost:3000
```

### 3. Использовать
- Web интерфейс работает с API автоматически
- Если API недоступен - используется локальный поиск
- Поиск работает по всем 105 документам

## 🧠 AI-Консультант (Phase 3 - Step 1 ✅)

### Архитектура RAG (Retrieval Augmented Generation)

```
Zapros polzovatelja
       |
       v
[Kontekst] <-- SQLite poisk (top-5 dokumentov)
       |
       v
[Formuly]  <-- Relevantnye formuly
       |
       v
[Praktiki] <-- Relevantnye praktiki
       |
       v
Prompt dlja OpenAI
       |
       v
OpenAI API (gpt-3.5-turbo)
       |
       v
Otvet AI
```

### Ispolzovanie

```python
from ai_consultant import AIConsultant

consultant = AIConsultant()
result = consultant.ask("Chto znachit put zhizni 7?")
print(result['answer'])
```

## 📊 Istorija raschetov (Phase 3 - Step 2 ✅)

### Vozmozhnosti

- **Profili polzovatelej**: Sozdanie, avtorizacija
- **Sohranenie raschetov**: Vse raschety v SQLite
- **Statistika**: Po tipam, srednie znachenija
- **Jeksport**: JSON i HTML formaty
- **Istorija**: Hronologicheskij spisok vseh raschetov

## 🤖 Telegram Bot (Phase 3 - Step 3 ✅)

### Komandy bota

- `/start` - Privetstvie
- `/help` - Spravka po komandam
- `/menu` - Glavnoe menju s knopkami
- `/life DD MM YYYY` - Put zhizni
- `/birth DD` - Chislo rozhdenija
- `/destiny FIO` - Chislo sudby
- `/finance DD MM YYYY` - Finansovyj kanal
- `/chakras DD MM YYYY` - Balans chakr
- `/search [zapros]` - Poisk po baze
- `/practices` - Spisok praktik
- `/ask [vopros]` - AI-konsultant

### Osobennosti

- **Avtoraspoznavanie daty**: Napishi 15.06.1990 - poluchish vse raschety
- **Inline knopki**: Udobnoe menju
- **AI v Telegram**: Zadavaj voprosy cherez /ask
- **Bystryj dostup**: Vse raschety v odnom meste

### Zapusk

```bash
export TELEGRAM_BOT_TOKEN="vash-token-ot-botfather"
python telegram_bot.py
```

---

**Статус:** ✅ VSE FAZY ZAVERSHENY!  
**Дата zavershenija:** 18.02.2026  
**Itogo:** 3 fazy, 15+ modulej, 3 interfejsa (CLI, Web, Telegram)
---

## 🔨 Sprint 5.3 «Полировка» — НАЧАТО 2026-02-19

### Задачи:
1. **5.3.1 — Wizard-практики** `index.html`: модальное окно → step-by-step wizard с countdown-таймером
2. **5.3.2 — Empty/Error states** `index.html`: error-banner, skeleton-loader, empty-search-hint  
3. **5.3.3 — Deploy** `Dockerfile` + `Procfile` + `render.yaml`

### Архитектура wizard-модала (5.3.1):
```
openPr(p)
  └── buildWizard(p)
        ├── шапка: название + прогресс-бар (step N / M)
        ├── тело: текст текущего шага + timer (если > 1 мин)
        ├── кнопки: «← Назад» / «Далее →» / «✓ Завершить»
        └── состояние в JS: {step, timerInterval}
```

### Архитектура error/empty states (5.3.2):
```
showError(msg)   → #error-banner (dismissible toast)
showSkeleton(n)  → n skeleton-карточек пока данные грузятся
showEmptySearch  → иллюстрация + подсказка + кнопка «Очистить»
```

### Docker-архитектура (5.3.3):
```
FROM python:3.11-slim
COPY . /app
RUN pip install -r requirements.txt
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

---

## ✅ Sprint 5.3 «Полировка» — ЗАВЕРШЕНО 2026-02-19

### Что реализовано:

#### 5.3.1 — Wizard-практики (`index.html`)
```
WIZ = {steps, step, timer, practice}    ← глобальное состояние

openPr(js)      → инициализирует WIZ, вызывает renderWiz()
renderWiz(p)    → строит HTML wizard-шага:
                  • прогресс-бар (pct = step/total * 100%)
                  • текст шага
                  • .wiz-timer (если в тексте «N минут/секунд»)
                  • кнопки Назад / Далее / Завершить
wizStep(dir)    → WIZ.step ±1, перерисовывает
wizDone()       → финальный экран «✦ Практика завершена!»
toggleTimer(s)  → setInterval countdown, обновляет #wiz-tv
```

#### 5.3.2 — Error / Empty states (`index.html`)
| Функция | Триггер | Поведение |
|---------|---------|-----------|
| `showError(msg)` | catch в fetch | Fixed toast, auto-dismiss 6s |
| `skeletonCards(n)` | перед загрузкой расчётов | n shimmer-карточек |
| `skeletonList(n)` | перед поиском/формулами | n shimmer-строк |
| `showEmptySearch(q)` | пустые результаты поиска | Иллюстрация + кнопка сброса |

#### 5.3.3 — Deploy files
| Файл | Платформа | Команда |
|------|-----------|---------|
| `Dockerfile` | Docker / любая | `docker build -t app . && docker run -p 8000:8000 app` |
| `Procfile` | Railway / Heroku | автоматически |
| `render.yaml` | Render.com | подключить репозиторий → автодеплой |
| `.dockerignore` | Docker | исключает __pycache__, .env, *.db |

### Итоговая архитектура Phase 5 (полностью завершена):
```
index.html (710 строк)
├── CSS: тёмная тема, responsive, wizard, skeleton, error-banner
├── HTML: sidebar, 5 секций, 2 модала (документ + wizard-практика)
└── JS:
    ├── NAV: showPage, showError, hideError
    ├── DATA: ensureLocal, loadStats, loadCats
    ├── CALC: calculate → skeletonCards → renderRes
    ├── SEARCH: debSearch → skeletonList → renderSearch / showEmptySearch
    ├── AI: sendMsg, addTyping, removeEl
    ├── PRACTICES: loadPractices → pr-grid → openPr → wizard
    └── FORMULAS: loadFormulas → skeletonList → result-cards

main.py (FastAPI, единый сервер, порт 8000)
├── /api/search   — FTS5 + BM25
├── /api/calculate — нумерологические расчёты
├── /api/ask      — RAG + OpenAI
├── /api/formulas, /api/practices, /api/stats, /api/categories
└── /             — StaticFiles → app/index.html
```

---

## 🚀 Phase 4-W «Web Scale» — НАЧАТО 2026-02-19

### Контекст старта
- Phase 5 завершена: единый FastAPI, FTS5, тёмный UI, wizard-практики, skeleton-states
- index.html: 709 строк | number_meanings.json: rich data (positive/negative/professions) не используется
- practices.json: 5 из 8 практик имеют steps=[] — заполняем
- Phase 4 Scale (React Native) — отложено; делаем Web-адаптацию

### Архитектура нового функционала

#### История расчётов (localStorage)
```
localStorage['calc_history'] = JSON array (max 50):
[{date, day, month, year, name, results:{life_path,birth,finance,destiny}}, ...]

saveToHistory(data)   → prepend + trim to 50 + localStorage.setItem
loadHistory()         → JSON.parse || []
renderHistory()       → timeline карточек с датой и кратким результатом
clearHistory()        → confirm + localStorage.removeItem
```

#### URL-sharing
```
shareURL()  → ?d=15&m=6&y=1990&n=Иван → navigator.clipboard
parseURLParams() @ DOMContentLoaded → автозаполнение + автозапуск calculate()
```

#### Expandable карточки
```
result-card
  ├── [существующий контент: num, title, keywords, desc]
  └── [новый] .card-detail (hidden по умолчанию)
        ├── .trait-section: positive chips (зелёные)
        ├── .trait-section: negative chips (красные)
        └── .prof-section: профессии chips (синие)
toggleCardDetail(cardEl) → classList.toggle('expanded')
```

---

## ✅ Phase 4-W «Web Scale» — ЗАВЕРШЕНО 2026-02-19

### Что реализовано:

#### 4W.1 — История расчётов (`index.html`)
```
localStorage['calc_history'] = JSON array, max 50 записей
Структура записи: {ts, date, day, month, year, name, nums:{birth,life,finance,destiny}}

saveToHistory(data)       → prepend + дедупликация по дате + trim 50 + setItem
loadHistory()             → JSON.parse || []
renderHistory()           → timeline .hist-card (дата | числа | имя)
restoreFromHistory(js)    → заполняет форму + navigate home + calculate()
clearHistory()            → confirm + removeItem + re-render
updateHistBadge()         → показывает количество в nav-badge
```

#### 4W.2 — Экспорт / URL-sharing (`index.html`)
```
copyResult()    → текстовый отчёт (дата, 4 числа с расшифровкой) → clipboard
shareURL()      → ?d=15&m=6&y=1990&n=Иван → clipboard
parseURLParams()→ @ DOMContentLoaded → автозаполнение + setTimeout(calculate,400)
```

#### 4W.3 — Expandable карточки (`index.html`)
```
result-card[onclick=toggleDetail(this)]
  └── .card-detail (display:none по умолчанию)
        ├── positive → .trait-chip.pos (зелёные)
        ├── negative → .trait-chip.neg (красные)
        └── professions → .trait-chip.prof (синие)
.result-card.expanded .card-detail { display:block }
CSS: .detail-toggle .arr { transition: transform .25s }
```

#### 4W.4 — Обогащение practices.json
| Практика | Было | Стало |
|---------|------|-------|
| Плетение Родового пояса | 0 шагов | 6 шагов |
| Принятие исключённых | 0 шагов | 6 шагов |
| Беседа с внутренним ребёнком | 0 шагов | 7 шагов |
| Сборник медитаций | 0 шагов | 4 шагов |
| Сборник молитв | 0 шагов | 5 шагов |

### Итоговые метрики проекта (2026-02-19)
```
index.html:     920 строк  (было 519 в Phase 5 старт)
practices.json: 8/8 практик со шагами (было 3/8)
JS функций:     ~35 (новые: saveToHistory, loadHistory, renderHistory,
                 restoreFromHistory, clearHistory, updateHistBadge,
                 copyResult, shareURL, parseURLParams, toggleDetail)
LocalStorage:   bday (последний ввод) + calc_history (массив)
URL params:     ?d=&m=&y=&n= → автоматический расчёт при открытии
```

---

## 🔍 Аудит 2026-02-19 (перед Phase 6)

| # | Тип | Проблема | Статус |
|---|-----|----------|--------|
| 1 | ❌ CRITICAL | `#error-banner` CSS: `display:none` + `display:flex` в одном правиле → баннер виден всегда | Исправлен |
| 2 | ⚠️ STAT | Phase 5 deliverables помечены `pending` несмотря на реализацию | Исправлен |
| 3 | ⚠️ DATA | `number_meanings.json`: числа 11 и 22 без `positive`/`negative`/`professions` | Исправлен |
| 4 | ⚠️ UX | Нет визуализации профиля и рекомендаций практик | Phase 6 |

---

## 🚀 Phase 6 «Визуализация и Рекомендации» — НАЧАТО 2026-02-19

### Архитектура Canvas radar chart (Sprint 6.2)
```
drawRadar(mountId, nums)
  Входные данные: {birth, life, finance, destiny}  (null = не введено)
  Нормализация:   1→15%, 9→85%, 11→92%, 22→100%
  Canvas:         320×320px, devicePixelRatio-aware (retina)
  Оси:            4 штуки, угол = 360°/4 = 90°, старт сверху
  Фон:            4 концентрических полигона (opacity 0.06)
  Заливка:        radialGradient gold(0)→purple(60%)→gold(100%), opacity 0.35
  Анимация:       requestAnimationFrame, progress 0→1 за ~800ms (step 0.035/frame)
  Точки:          цветные dots на вершинах (4 уникальных цвета)
  Подписи:        label сокращённый + число рядом с вершиной

DOM after renderRes:
  #results-home
    ├── .results-grid       (4 карточки)
    ├── #radar-mount        ← .radar-section (canvas + legend)
    ├── #reco-mount         ← .reco-section (3 карточки практик)
    └── .export-bar
```

### Архитектура рекомендаций (Sprint 6.3)
```javascript
RECO_MAP = {
  1:  [0,4,3],   // Генограмма, Поклоны, Принятие исключённых
  2:  [2,5,7],   // Благословение, Беседа с ребёнком, Молитвы
  3:  [1,6,2],   // Пояс, Медитации, Благословение
  4:  [0,3,4],   // Генограмма, Принятие, Поклоны
  5:  [5,6,1],   // Беседа с ребёнком, Медитации, Пояс
  6:  [2,7,3],   // Благословение, Молитвы, Принятие
  7:  [6,5,0],   // Медитации, Беседа с ребёнком, Генограмма
  8:  [1,4,7],   // Пояс, Поклоны, Молитвы
  9:  [3,2,6],   // Принятие, Благословение, Медитации
  11: [5,6,2],   // Беседа с ребёнком, Медитации, Благословение
  22: [0,1,4],   // Генограмма, Пояс, Поклоны
}

renderRecommendations(mountId, num)
  → await ensureLocal()                      (данные уже загружены)
  → LOCAL.p[RECO_MAP[num]]                  (3 практики по индексам)
  → рендер .reco-card с btn → openPr(JSON)  (запускает wizard)
```

### ✅ Phase 6 ЗАВЕРШЕНА — 2026-02-19

| Sprint | Задача | Реализация |
|--------|--------|-----------|
| 6.1.1 | error-banner CSS fix | `display:flex` в базовом правиле; видимость только через `.hidden{display:none!important}` |
| 6.1.2 | Мастер-числа 11 и 22 | 6 pos / 6 neg / 8 prof для каждого |
| 6.2.1 | Canvas radar chart | `drawRadar()`: 300×300 DPR-aware, easeOutCubic 800ms, radialGradient |
| 6.3.1 | Рекомендации практик | `RECO_MAP` + `renderRecommendations()`, 3 карточки → wizard |

**Итоговые метрики:**
- `index.html`: 920 → 1142 строки (+222)
- `number_meanings.json`: 11/11 чисел с positive/negative/professions
- JS syntax check: ✅ node --check

---

## 🚀 Phase 8 «Кабинет практика + Расширенный API» — НАЧАТО 2026-02-19

### Аудит pdf3.zip перед стартом
```
app/index.html : 1142 строки — Phase 6 завершена ✅
main.py        : 425 строк  — FastAPI v3.0, FTS5 ✅
DevelopmentPlan: Phases 1,2,3,5,4W,6 = completed
PENDING        : 4.2 комментарии, 4.3 кабинет, 4.4 расш. API
```

### Архитектура новых компонентов

#### 8.1 — Комментарии к практикам
```
localStorage['practice_comments'] = {
  "practice_id": [
    { ts: "2026-02-19T12:00:00Z", text: "Текст заметки" },
    ...
  ]
}

Функции:
  saveComment(prId, text)    → prepend + trim 20 + setItem
  loadComments(prId)         → JSON.parse['practice_comments'][prId] || []
  deleteComment(prId, idx)   → splice + setItem
  renderComments(prId, mountId) → timeline в wizard-финале
```

#### 8.2 — Кабинет практика
```
localStorage['practitioner_clients'] = [
  {
    id: "uuid-like",
    name: "Иван Петров",
    day: 15, month: 6, year: 1990,
    notes: [],               // [{ts, text}]
    sessions: []             // [{ts, results:{birth,life,finance,destiny}}]
  }
]

Новая секция: page-cabinet
Новый nav-btn: «◈ Кабинет»

Функции:
  addClient(name, day, month, year)  → uuid + push + setItem + renderClients()
  deleteClient(id)                   → filter + setItem + renderClients()
  calcClient(id)                     → localCalc() → session → setItem → showSession()
  saveClientNote(id, text)           → push note + setItem
  renderClients()                    → карточки клиентов
  renderClientModal(id)              → модал: профиль + история сеансов + заметки
```

#### 8.3 — Расширенный API (main.py)
```
POST /api/bulk-calculate
  Body: { clients: [{day, month, year, name?}] }   (max 50)
  Response: { results: [{ ...calcResult, index }] }

GET /api/export
  Query: ?day=15&month=6&year=1990&name=Иван
  Response: text/plain — форматированный отчёт
  Content-Disposition: attachment; filename="numerology_report.txt"
```

### Итоговая карта секций app/index.html после Phase 8
```
page-home       → расчёт + radar + reco  ✅ Phase 6
page-search     → поиск + фильтры        ✅ Phase 5
page-ai         → chat AI                ✅ Phase 5
page-practices  → wizard + комментарии   ✅ Phase 8.1 NEW
page-formulas   → 15 формул              ✅ Phase 5
page-history    → localStorage timeline   ✅ Phase 4W
page-cabinet    → кабинет практика       ✅ Phase 8.2 NEW
```

---

## ✅ Phase 8 «Кабинет практика + Расширенный API» — ЗАВЕРШЕНО 2026-02-19

### Что реализовано

#### 8.1 — Комментарии к практикам (`app/index.html`)
| Функция | Описание |
|---------|----------|
| `saveComment(prId)` | Сохраняет заметку в localStorage['practice_comments'][id] (max 20) |
| `loadComments(prId)` | Читает массив заметок для практики |
| `deleteComment(prId, idx)` | Удаляет заметку по индексу |
| `renderComments(prId)` | Рендерит список заметок с датами и кнопками удаления |
| `updatePrBadge(prId)` | Обновляет бейдж «📝 N заметок» на карточке практики |

`wizDone()` расширен — финальный экран теперь содержит блок комментариев.

#### 8.2 — Кабинет практика (`app/index.html`)
```
Новая секция: page-cabinet (7-я секция)
Новый nav-btn: «◉ Кабинет» + cab-badge (количество клиентов)

localStorage['practitioner_clients'] = [
  { id, name, day, month, year,
    notes:[{ts,text}],          // заметки практика (max 50)
    sessions:[{ts,results}]     // история расчётов (max 30)
  }
]

Функции (9 штук):
  loadClients()           → JSON.parse || []
  saveClients(list)       → JSON.stringify + setItem
  genId()                 → Date.now().toString(36) + random
  updateCabBadge()        → счётчик клиентов в nav
  toggleAddForm()         → открыть/закрыть форму добавления
  addClient()             → валидация → localCalc() → push → renderClients()
  deleteClient(id)        → confirm → filter → saveClients()
  calcClient(id)          → localCalc() → session.unshift → saveClients()
  openClientModal(id)     → mod-client: история сеансов + форма заметок
  saveClientNote(id)      → note.unshift → saveClients() → openClientModal()
  deleteClientNote(id,idx)→ notes.splice → saveClients() → openClientModal()
  renderClients()         → clients-grid: карточки с num-chips и действиями
```

#### 8.3 — Расширенный API (`main.py` v4.0)
```
POST /api/bulk-calculate
  Model: BulkClientItem {day, month, year, name?}
  Model: BulkRequest    {clients: BulkClientItem[]} (max 50)
  Logic: HybridKnowledgeBase → birth/life/finance/destiny для каждого
  Response: {results:[{index,name,success,birth_number,life_path,...}]}

GET /api/export
  Query: day, month, year, name? (validation: ge/le constraints)
  Response: PlainTextResponse, charset=utf-8
  Content-Disposition: attachment; filename="numerology_DD.MM.YYYY.txt"
  Format: рамки ═══, числа + заголовок + ключевые слова + описание (200 chars)
```

### Итоговые метрики Phase 8
```
app/index.html : 1142 → 1471 строк (+329)
main.py        : 425  → 536 строк (+111), version 3.0 → 4.0
Новых JS функций: 16
Новых API endpoints: 2
Новых localStorage ключей: 2 (practice_comments, practitioner_clients)
JS syntax node --check: ✅ (969 строк)
Python syntax ast.parse: ✅
```

### Полная карта секций `app/index.html` — финальное состояние
| Секция | Содержимое | Phase |
|--------|------------|-------|
| page-home | расчёт + radar chart + рекомендации | Phase 6 |
| page-search | FTS5 поиск + фильтры по категориям | Phase 5 |
| page-ai | chat AI (история, typing dots, shortcuts) | Phase 5 |
| page-practices | wizard + таймер + **комментарии (NEW)** | **Phase 8.1** |
| page-formulas | 15 нумерологических формул | Phase 5 |
| page-history | localStorage timeline (max 50) | Phase 4W |
| page-cabinet | **Кабинет практика — клиенты, сеансы, заметки (NEW)** | **Phase 8.2** |

### Следующие шаги (Phase 4 Scale — отложено)
- 4.1 — Мобильное приложение (React Native / Flutter) — крупная задача
- PWA offline support — service worker + cache API

---

## 🔍 Phase 9 «PWA + XML Repair» — НАЧАТО 2026-02-19

### Аудит pdf4.zip перед стартом

| # | Проблема | Тип | Файл |
|---|----------|-----|------|
| 1 | mismatched tag — orphan `<Task>` элементы 5.2.x после закрытого `</Sprint>` | КРИТИЧНО | DevelopmentPlan.xml:350 |
| 2 | Дубли Task id: 3.2, 3.3, 5.2.1-5.2.5 | ОШИБКА | DevelopmentPlan.xml |
| 3 | Неэкранированные `&` в Description и комментариях | ОШИБКА | DevelopmentPlan.xml |
| 4 | Двойные `--` внутри XML-комментариев | ОШИБКА | DevelopmentPlan.xml |
| 5 | Phase 5 Goals: status=pending при completedDate=2026-02-19 | ОШИБКА | DevelopmentPlan.xml |
| 6 | PWA отсутствует — нет manifest.json, sw.js, иконок | GAP | app/ |

### Что уже есть (верифицировано аудитом)
```
app/index.html : 1471 строк — Phase 8 полная ✅
  - 7 секций: home/search/ai/practices/formulas/history/cabinet
  - 67 JS функций: calc, radar, reco, comments, cabinet
  - все фичи Phase 4W, 6, 8 работают
main.py        : 536 строк — FastAPI v4.0 ✅
  - 12 endpoints включая bulk-calculate и export
  - Python syntax OK
JS syntax      : node --check 969 строк ✅
```

### Архитектура PWA (Phase 9.2)

```
app/
├── manifest.json       ← installable PWA manifest
├── sw.js               ← Service Worker (offline cache)
├── icon-192.svg        ← иконка 192x192 (gold ✦ на тёмном фоне)
├── icon-512.svg        ← иконка 512x512 (same, maskable)
└── index.html          ← +meta PWA tags +SW register +install btn

Стратегии кэширования:
  CACHE_NAME = 'numerology-v4'

  install event → precache:
    '/', '../data/formulas.json', '../data/practices.json',
    '../data/number_meanings.json', '../data/algorithms.json'

  fetch event dispatch:
    URL matches /api/*          → Network-first (cache on success, fallback offline)
    URL matches *.json (data)   → Cache-first (network on miss)
    URL matches fonts.g*        → Stale-while-revalidate
    все остальные               → Cache-first (stale OK)

  activate event → remove old cache versions

Install UX:
  window.addEventListener('beforeinstallprompt', e => deferredPrompt = e)
  #btn-install click → deferredPrompt.prompt() → await userChoice
  window.addEventListener('appinstalled', → hide btn + toast)
  Кнопка #btn-install в sidebar-footer (hidden by default)
```

### index.html изменения (Phase 9.2.4)
```html
<head>
  <!-- PWA -->
  <link rel="manifest" href="manifest.json">
  <meta name="theme-color" content="#c8922a">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="Нумерология">
  <link rel="apple-touch-icon" href="icon-192.svg">
</head>

<aside class="sidebar">
  ...
  <div class="sidebar-footer">
    <span id="sf">Загрузка…</span>
    <button id="btn-install" style="display:none">📲 Установить</button>
  </div>
</aside>

<script>
  // PWA registration
  function registerSW() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js')
    }
  }
  let deferredPrompt = null
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault(); deferredPrompt = e
    document.getElementById('btn-install').style.display = 'block'
  })
  document.getElementById('btn-install').addEventListener('click', async () => {
    if (!deferredPrompt) return
    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice
    deferredPrompt = null
    document.getElementById('btn-install').style.display = 'none'
  })
  window.addEventListener('appinstalled', () => {
    document.getElementById('btn-install').style.display = 'none'
    showError('✅ Приложение установлено!', 3000)
  })
</script>
```

---

## ✅ Phase 9 «PWA + XML Repair» — ЗАВЕРШЕНО 2026-02-19

### Что реализовано

#### 9.1 — XML Repair (DevelopmentPlan.xml)
| Ошибка | Метод исправления |
|--------|-------------------|
| mismatched tag line 350 (orphan Tasks после </Sprint>) | `re.sub` удалил блок строк 324–349 |
| Дубли Task id 3.2, 3.3, 5.2.1-5.2.5 | Дубли удалены; 3.4/3.5 помечены completed |
| Неэкранированные `&` в Description/комментариях | `re.sub r'&(?!amp;...)' → &amp;` |
| Двойные `--` в XML-комментариях | `re.sub в <!--...-->: -- → - -` |
| Phase 5 Goals: status=pending при completed фазе | regex замена в блоке Phase 5 |

**Результат:** python3 ET.parse → OK, 9 phases, 1 pending (4.1 mobile)

#### 9.2 — PWA Files

| Файл | Размер | Назначение |
|------|--------|-----------|
| `app/manifest.json` | 60 строк | installable PWA: name/icons/shortcuts/theme |
| `app/sw.js` | 169 строк | Service Worker: 3 стратегии кэша |
| `app/icon-192.svg` | 36 строк | иконка 192×192 (gold ✦ на тёмном) |
| `app/icon-512.svg` | 47 строк | иконка 512×512 maskable |

#### 9.2.2 — sw.js архитектура
```
CACHE_NAME = 'numerology-v4'   ← app shell (HTML, CSS, JS, SVG icons)
CACHE_DATA = 'numerology-data-v4'  ← data JSON (stable)
CACHE_API  = 'numerology-api-v4'   ← API responses (TTL cache)

Events:
  install  → precache PRECACHE_STATIC + PRECACHE_DATA → skipWaiting()
  activate → delete old cache versions → clients.claim()
  fetch    → dispatch by URL:
    /api/*                → networkFirst(CACHE_API)
    /data/*.json          → cacheFirst(CACHE_DATA)
    fonts.googleapis.com  → staleWhileRevalidate(CACHE_NAME)
    *                     → cacheFirst(CACHE_NAME)
  message  → SKIP_WAITING | CACHE_PURGE

Offline fallbacks:
  API → JSON {error:'offline', message:'...'}
  Navigate → cached '/' or '/index.html'
  Other → '503 Offline'
```

#### 9.2.4 — index.html изменения
```
+head: <link rel="manifest">, theme-color, apple-mobile-web-app-*, favicon SVG
+sidebar-footer: #btn-install (скрыт по умолчанию, gold bordered button)
+CSS: .btn-install, .sw-status (fade-in toast)
+JS:
  registerSW()           → navigator.serviceWorker.register('sw.js')
  installPWA()           → deferredPrompt.prompt() + userChoice
  handleShortcut()       → ?s=section → showPage() (PWA shortcuts support)
  window.beforeinstallprompt → show #btn-install
  window.appinstalled    → hide #btn-install + toast
  DOMContentLoaded: registerSW() + handleShortcut() || parseURLParams()
```

#### 9.x — main.py v4.0 → v4.1
```python
class PWAHeadersMiddleware(BaseHTTPMiddleware):
    # sw.js: Service-Worker-Allowed: /
    # sw.js: Cache-Control: no-cache
    # all:   X-Content-Type-Options: nosniff
```

### Итоговые метрики Phase 9
```
index.html      : 1471 → 1550 строк (+79)
main.py         : 536  → 553  строк (+17), v4.0 → v4.1
DevelopmentPlan : 891  → 966  строк, XML ✅ (9 phases)
Architecture.md : рост документации
Новых файлов    : 4 (manifest.json, sw.js, icon-192.svg, icon-512.svg)
JS lines        : 969 → 1027 (+58), node --check ✅
Python syntax   : ast.parse ✅
```

### Финальная карта всего проекта (Phase 9 done)
| Phase | Что сделано | Файлы | Статус |
|-------|-------------|-------|--------|
| 1 MVP | CLI калькулятор 15 формул | calculator_cli.py | ✅ |
| 2 Core | Web UI + API сервер + FTS поиск | app/index.html, api_server.py | ✅ |
| 3 Advanced | AI RAG + Telegram bot + история | ai_consultant.py, telegram_bot.py | ✅ |
| 5 Refactor | FastAPI unified, FTS5, тёмная тема, чат AI | main.py, index.html | ✅ |
| 4W Web Scale | localStorage история, expandable cards, export | index.html | ✅ |
| 6 Visualization | Canvas radar chart, рекомендации практик | index.html | ✅ |
| 8 Cabinet | Комментарии, кабинет практика, bulk API, export | index.html, main.py | ✅ |
| 9 PWA | manifest, SW, иконки, install prompt, XML repair | app/*.json/svg/js | ✅ |
| 4.1 Mobile | React Native / Flutter | — | ⏳ отложено |

### Как запустить
```bash
pip install -r requirements.txt
python main.py
# → http://localhost:8000
# → Chrome: кнопка «Установить» появится в адресной строке / sidebar
# → Offline: открывай кэшированную версию без сервера
```
